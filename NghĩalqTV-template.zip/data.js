const ADMIN = {
  name: "Nghialq TV",
  avatar: "assets/img/avatar.png",
  telegram: "https://t.me/yourchannel"
};

const APPS = [
  {
    id: "aov",
    name: "Hack Map AOV 6.0",
    version: "Cập nhật 03/01",
    link: "LINK_TẢI_APP"
  }
];

const KEYS = [
  {
    name: "Get Key IOS",
    info: "1.5 Day",
    link: "LINK_GET_KEY"
  }
];

const FILES = [
  {
    title: "Pack Skin Conan",
    image: "assets/img/banner.jpg",
    link: "LINK_TẢI_FILE"
  }
];